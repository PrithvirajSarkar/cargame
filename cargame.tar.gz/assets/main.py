import pygame
import random
import asyncio

pygame.init()

WIDTH, HEIGHT = 900, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Velocity Rush")

WHITE = (255,255,255)
BLACK = (0,0,0)

player_img = pygame.transform.scale(pygame.image.load("myCar.png"), (60,100))
enemy_img = pygame.transform.scale(pygame.image.load("enemyCar.png"), (60,100))
road = pygame.transform.scale(pygame.image.load("road.png"), (WIDTH,HEIGHT))

font = pygame.font.SysFont(None,30)
big_font = pygame.font.SysFont(None,60)

clock = pygame.time.Clock()

# GAME STATES
state = "menu"
difficulty = "easy"
high_score = 0

# GAME VARIABLES
player_x = WIDTH//2
player_y = HEIGHT-120
road_y = 0
score = 0
base_speed = 4
enemies = []

def reset_game():
    global enemies, score, player_x
    enemies = [[random.randint(100, WIDTH-100), -200, base_speed] for _ in range(3)]
    score = 0
    player_x = WIDTH//2

async def game():

    global state, difficulty, high_score
    global player_x, road_y, score, base_speed

    while True:

        # EVENTS
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return

            if state == "menu":
                if event.type == pygame.MOUSEBUTTONDOWN:
                    state = "difficulty"

            elif state == "difficulty":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_1:
                        difficulty = "easy"
                        base_speed = 4
                        reset_game()
                        state = "game"
                    if event.key == pygame.K_2:
                        difficulty = "medium"
                        base_speed = 6
                        reset_game()
                        state = "game"
                    if event.key == pygame.K_3:
                        difficulty = "hard"
                        base_speed = 9
                        reset_game()
                        state = "game"

            elif state == "gameover":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        reset_game()
                        state = "menu"
                    if event.key == pygame.K_q:
                        state = "menu"

        # DRAW STATES

        if state == "menu":
            screen.fill(BLACK)
            title = big_font.render("VELOCITY RUSH", True, WHITE)
            screen.blit(title,(WIDTH//2-title.get_width()//2,150))

            txt = font.render("CLICK TO PLAY", True, WHITE)
            screen.blit(txt,(WIDTH//2-txt.get_width()//2,300))

        elif state == "difficulty":
            screen.fill(BLACK)
            title = big_font.render("SELECT DIFFICULTY", True, WHITE)
            screen.blit(title,(WIDTH//2-title.get_width()//2,100))

            screen.blit(font.render("1 - EASY",True,(0,255,150)),(WIDTH//2-80,250))
            screen.blit(font.render("2 - MEDIUM",True,(255,200,0)),(WIDTH//2-80,300))
            screen.blit(font.render("3 - HARD",True,(255,80,80)),(WIDTH//2-80,350))

        elif state == "game":

            keys = pygame.key.get_pressed()

            # MOVEMENT
            if keys[pygame.K_LEFT]:
                player_x -= 7
                tilt = -10
            elif keys[pygame.K_RIGHT]:
                player_x += 7
                tilt = 10
            else:
                tilt = 0

            # SPEED CONTROL
            speed = base_speed
            if keys[pygame.K_LSHIFT]: speed += 4
            if keys[pygame.K_DOWN]: speed = max(2, base_speed - 3)

            road_y = (road_y + speed) % HEIGHT

            screen.blit(road,(0,road_y))
            screen.blit(road,(0,road_y-HEIGHT))

            # ENEMIES
            for en in enemies:
                en[1] += en[2]

                if en[1] > HEIGHT:
                    en[1] = -200
                    en[0] = random.randint(100, WIDTH-100)
                    score += 1
                    if score > high_score:
                        high_score = score

                screen.blit(enemy_img,(en[0],en[1]))

            # PLAYER
            rotated = pygame.transform.rotate(player_img, tilt)
            rect = rotated.get_rect(center=(player_x+30, player_y+50))
            screen.blit(rotated, rect.topleft)

            player_rect = rotated.get_rect(topleft=rect.topleft)

            # COLLISION
            for en in enemies:
                if player_rect.colliderect(enemy_img.get_rect(topleft=(en[0],en[1]))):
                    state = "gameover"

            # UI LEFT
            screen.blit(font.render(f"Score: {score}",True,BLACK),(10,10))
            screen.blit(font.render(f"High: {high_score}",True,BLACK),(10,40))

            # UI RIGHT
            controls = ["SHIFT - Nitro","DOWN - Brake","< > Move"]
            for i, t in enumerate(controls):
                txt = font.render(t,True,BLACK)
                screen.blit(txt,(WIDTH - txt.get_width() - 10,10 + i*25))

        elif state == "gameover":
            screen.fill(BLACK)
            over = big_font.render("GAME OVER", True, WHITE)
            screen.blit(over,(WIDTH//2-over.get_width()//2,200))

            restart = font.render("R - Restart",True,WHITE)
            quit_txt = font.render("Q - Quit",True,WHITE)
            screen.blit(restart,(WIDTH//2-restart.get_width()//2,300))
            screen.blit(quit_txt,(WIDTH//2-quit_txt.get_width()//2,340))
        pygame.display.update()
        clock.tick(60)

        await asyncio.sleep(0)

asyncio.run(game())