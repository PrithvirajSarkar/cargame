import pygame
import random
import sys

pygame.init()

WIDTH, HEIGHT = 900, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Velocity Rush")

WHITE = (255,255,255)
BLACK = (0,0,0)

player_car = pygame.transform.scale(pygame.image.load("myCar.png"), (60,100))
enemy_car = pygame.transform.scale(pygame.image.load("enemyCar.png"), (60,100))
road = pygame.transform.scale(pygame.image.load("road.png"), (WIDTH,HEIGHT))

font = pygame.font.SysFont(None,30)
big_font = pygame.font.SysFont(None,60)

clock = pygame.time.Clock()

state = "menu"
difficulty = "easy"
high_score = 0

player_x = WIDTH//2
player_y = HEIGHT-120

enemies = []
score = 0
base_speed = 4
road_y = 0

def reset_game():
    global enemies, score, base_speed, player_x
    enemies = [[random.randint(100,WIDTH-100), -200, base_speed] for _ in range(3)]
    score = 0
    player_x = WIDTH//2

import asyncio

async def game():

    global state, difficulty, high_score
    global player_x, player_y, enemies, score, base_speed, road_y

    while True:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return

            if state == "menu":
                if event.type == pygame.MOUSEBUTTONDOWN:
                    state = "difficulty"

            elif state == "difficulty":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_1:
                        difficulty = "easy"
                        base_speed = 4
                        reset_game()
                        state = "game"
                    if event.key == pygame.K_2:
                        difficulty = "medium"
                        base_speed = 6
                        reset_game()
                        state = "game"
                    if event.key == pygame.K_3:
                        difficulty = "hard"
                        base_speed = 8
                        reset_game()
                        state = "game"

            elif state == "gameover":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        state = "menu"

        # -------- DRAW --------

        if state == "menu":
            screen.fill(BLACK)
            text = big_font.render("CLICK TO START", True, WHITE)
            screen.blit(text,(WIDTH//2-text.get_width()//2, HEIGHT//2))

        elif state == "difficulty":
            screen.fill(BLACK)
            title = big_font.render("SELECT DIFFICULTY", True, WHITE)
            screen.blit(title,(WIDTH//2-title.get_width()//2,100))

            screen.blit(font.render("1 EASY",True,(0,255,150)),(WIDTH//2-80,250))
            screen.blit(font.render("2 MEDIUM",True,(255,200,0)),(WIDTH//2-80,300))
            screen.blit(font.render("3 HARD",True,(255,80,80)),(WIDTH//2-80,350))

        elif state == "game":

            keys = pygame.key.get_pressed()

            if keys[pygame.K_LEFT]: player_x -= 7
            if keys[pygame.K_RIGHT]: player_x += 7

            speed = base_speed
            if keys[pygame.K_LSHIFT]: speed += 4
            if keys[pygame.K_DOWN]: speed = max(2, base_speed-3)

            road_y = (road_y + speed) % HEIGHT

            screen.blit(road,(0,road_y))
            screen.blit(road,(0,road_y-HEIGHT))

            for en in enemies:
                en[1] += en[2]
                if en[1] > HEIGHT:
                    en[1] = -200
                    en[0] = random.randint(100,WIDTH-100)
                    score += 1

                screen.blit(enemy_car,(en[0],en[1]))

            screen.blit(player_car,(player_x,player_y))

            player_rect = player_car.get_rect(topleft=(player_x,player_y))

            for en in enemies:
                if player_rect.colliderect(enemy_car.get_rect(topleft=(en[0],en[1]))):
                    state = "gameover"

            screen.blit(font.render(f"Score: {score}",True,BLACK),(10,10))

        elif state == "gameover":
            screen.fill(BLACK)
            over = big_font.render("GAME OVER", True, WHITE)
            screen.blit(over,(WIDTH//2-over.get_width()//2,200))
            screen.blit(font.render("R - Restart",True,WHITE),(WIDTH//2-80,300))

        pygame.display.update()
        clock.tick(60)

        await asyncio.sleep(0)   # 🔥 THIS LINE FIXES EVERYTHING

# RUN
asyncio.run(game())